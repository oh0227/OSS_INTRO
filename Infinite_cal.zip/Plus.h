int plus(DLL a, DLL b){
    
    char c1 = a->head->val;
    char c2 = b->head->val;
    int one = 0;
    int two = 0;
    one = c1 - '0';
    two = c2 - '0';



    return ans;
}
